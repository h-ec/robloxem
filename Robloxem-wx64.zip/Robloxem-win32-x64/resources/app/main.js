const { app, BrowserWindow } = require("electron");
const path = require("path");

let window;

const createWindow = () => {
    window = new BrowserWindow({
        icon: path.join(__dirname + "/app-icon-roblox.ico"),
        width: 1024,
        minWidth: 800,
        height: 600,
        minHeight: 400,
        title: "Roblox Menu",
        show: false,
        autoHideMenuBar: true,
        webPreferences: {
            devTools: false,
        },
    });

    window.setAutoHideMenuBar(null);

    window.loadURL("https://www.roblox.com/home");

    window.once("ready-to-show", function(){
        window.show();
    });
};

app.whenReady().then(() => {
    createWindow();
});